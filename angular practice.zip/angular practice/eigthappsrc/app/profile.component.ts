import { Component } from '@angular/core';

@Component({
  selector: 'app-profile',
  template: `<h2>Profile page</h2>`
})
export class ProfileComponent { }