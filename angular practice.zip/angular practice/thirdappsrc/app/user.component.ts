import {Component} from '@angular/core';
@Component({
    selector: 'app-root',
    templateUrl: './user.component.html', 
    styleUrls: ['./user.component.css']
})
export class UserComponent {
	users = [
         'Mahesh',
         'Krishna',
         'Narendra',
	 'Jitendra'
    ];
	getCSSClasses(flag:string) {
	  let cssClasses;
	  if(flag == 'nightMode') {  
        cssClasses = {
	       'one': true,
		   'two': true 
	    }	
	  } else {  
        cssClasses = {
	       'two': true,
		   'four': false 
	    }	
	  }
	  return cssClasses;
    }	
 }
  click()
  {
	  this.count++;
	  switch(count)
	  {
		  case 1:this.myclass={'one':true};
				  break;
		  case 2:this.myclass={'two':true};
				  break;
		  case 3:this.myclass={'three':true};
				  break;
		 default:
	  }
  }