import { Component } from '@angular/core';
import {FilterData} from './filterData';
@Component({
  selector: 'app-root',
	template: ` <input type="text" #filter (keyup)="0">
	
	<table style="border-style:solid; border-width:1px">
	<th style="border-style:solid; border-width:1px"> Data</th>
	<tbody>
			<tr *ngFor="let point of (points|filterData:filter.value)">
	<td>{{point}}</td>
	</tr>
	<tbody>
	</table>` ,
	providers: [FilterData]	
})

export class AppComponent {
	points: string[] = [
		 'aa',
		 'abb',
		 'aaa',
		 'dd' ,
		 'aahh',
		 'bbds',
		 'kdsjfhsd'
	];
	
	constructor(private fd: FilterData) {
		console.log("Length is "+this.fd.transform(this.points,"a").length);	
	}
}