import { Component, ɵɵpureFunction1 } from '@angular/core';
import {User} from './Users';
@Component({
  selector:'app-root',
  templateUrl:'./app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
isValid = true;
ids = [1,2,3,4];
title = 'app';

	users : User[] = [
      new User('Mahesh', 20,'gfghf'),
      new User('Krishna', 22,'hfsfs'),
      new User('Narendra', 31, 'hgsds')
    ];
    
 }
