package com.cts.BuyerService;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.cts.Buyer.Buyer;
import com.cts.BuyerDao.IPersonDao;
import com.cts.BuyerInterfaceservice.IBuyerService;

public class BuyerService implements IBuyerService {
	@Autowired
	private IPersonDao dao;
	@Override
	public Integer createOrUpdate(Buyer buyer) {
		Buyer b =(Buyer)dao.save(buyer);
		return b.getBuyerId();
	}

	@Override
	public void deleteById(Integer buyerId) {
Optional<Buyer> buyer = dao.findById(buyerId);
		
		if(buyer.isPresent()) {
		dao.deleteById(buyerId);
		}
		
		
	}

	@Override
	public Buyer update(Buyer buyer) {
		Optional<Buyer> per = dao.findById(buyer.getBuyerId());
		Buyer newBuyer = null;
		if(per.isPresent()) {
			 newBuyer = per.get();
			 newBuyer.setUserName(buyer.getUserName());
			 newBuyer.setPassword(buyer.getPassword());
			 newBuyer = dao.save( newBuyer);
		}
		return newBuyer;
	}

	@Override
	public Buyer getBuyerById(Integer id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Buyer getBuyerByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

}
