package com.cts.Buyer;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class TransactionEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int transactionId;
	//private int userId;
	private String transactionType;
	private Date date_time;
	private String tranRemarks;
	
	public TransactionEntity() {
		
	}
	public int getTranId() {
		return transactionId;
	}
	public void setTranId(int tranId) {
		this.transactionId = tranId;
	}
	/*public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}*/
	
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public String getTranRemarks() {
		return tranRemarks;
	}
	public void setTranRemarks(String tranRemarks) {
		this.tranRemarks = tranRemarks;
	}
	public TransactionEntity(int tranId, int userId, int sellerId, String transactionType, String tranRemarks) {
		super();
		this.transactionId = tranId;
		//this.userId = userId;
		
		this.transactionType = transactionType;
		this.tranRemarks = tranRemarks;
	}
	public Date getDate_time() {
		return date_time;
	}
	public void setDate_time(Date date_time) {
		this.date_time = date_time;
	}
	@Override
	public String toString() {
		return "TransactionEntity [transactionId=" + transactionId + ", transactionType=" + transactionType
				+ ", date_time=" + date_time + ", tranRemarks=" + tranRemarks + "]";
	}


}
