package com.cts.Buyer;

import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
//import javax.persistence.OneToMany;


@Entity
public class ShoppingCartEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int cartId;
	private String description;
	
	
	 /* @OneToMany
	 private ItemsEntity ct;
	  
	  public ItemsEntity getCt() {
	   return ct; 
	   }
	    public void setCt(ItemsEntity ct) {
	  this.ct = ct; 
	  }*/
	 
	
	
	public ShoppingCartEntity() {
		
	}
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public ShoppingCartEntity(int cartId, String description) {
		super();
		this.cartId = cartId;
		this.description = description;
	}
	@Override
	public String toString() {
		return "Cart [cartId=" + cartId + ", description=" + description + "]";
	}
	

}



