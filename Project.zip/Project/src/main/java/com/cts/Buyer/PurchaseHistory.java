package com.cts.Buyer;

import java.util.Date;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.transaction.Transaction;
@Entity
public class PurchaseHistory {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int purchaseId;
	@OneToOne
	private Buyer buyerId;
	@OneToOne
	private Transaction transactionId;
	@ManyToOne
	private Items itemId;
	private int numberOfItems;
	private Date dateTime;
	private String purchremarks;
	
	public PurchaseHistory() {
		
	}
	public int getPurId() {
		return purchaseId;
	}
	public void setPurId(int purId) {
		this.purchaseId = purId;
	}
public Buyer getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(Buyer buyerId) {
		this.buyerId = buyerId;
	}
	
	public Transaction getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(Transaction transactionId) {
		this.transactionId = transactionId;
	}
	public Items getItemId() {
		return itemId;
	}
	public void setItemId(Items itemId) {
		this.itemId = itemId;
	}
	public int getNumberOfItems() {
		return numberOfItems;
	}
	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}
	public String getPurchremarks() {
		return purchremarks;
	}
	public void setPurchremarks(String purchremarks) {
		this.purchremarks = purchremarks;
	}
	public PurchaseHistory(int purId,Buyer buyerId,  Transaction transactionId, Items itemId, int numberOfItems,
			String purchremarks) {
		super();
		this.purchaseId = purId;
		this.buyerId = buyerId;
		
		this.transactionId = transactionId;
		this.itemId = itemId;
		this.numberOfItems = numberOfItems;
		this.purchremarks = purchremarks;
	}
	@Override
	public String toString() {
		return "PurchaseHistory [purId=" + purchaseId + ", buyerId=" + buyerId + ", transactionId=" + transactionId
				+ ", itemId=" + itemId + ", numberOfItems=" + numberOfItems + ", dateTime=" + dateTime
				+ ", purchremarks=" + purchremarks + "]";
	}
	
	
}
