package com.cts.Buyer;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import com.cts.Buyer.BuyerEntity;
@Entity
public class PurchaseHistoryEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int purchaseId;
	@OneToOne
	private BuyerEntity buyerId;
	@OneToOne
	private TransactionEntity transactionId;
	@ManyToOne
	private ItemsEntity itemId;
	private int numberOfItems;
	private Date dateTime;
	private String purchremarks;
	
	public PurchaseHistoryEntity() {
		
	}
	public int getPurId() {
		return purchaseId;
	}
	public void setPurId(int purId) {
		this.purchaseId = purId;
	}
/*	public BuyerEntity getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(BuyerEntity buyerId) {
		this.buyerId = buyerId;
	}
	
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public ItemsEntity getItemId() {
		return itemId;
	}
	public void setItemId(ItemsEntity itemId) {
		this.itemId = itemId;
	}*/
	public int getNumberOfItems() {
		return numberOfItems;
	}
	public void setNumberOfItems(int numberOfItems) {
		this.numberOfItems = numberOfItems;
	}
	public String getPurchremarks() {
		return purchremarks;
	}
	public void setPurchremarks(String purchremarks) {
		this.purchremarks = purchremarks;
	}
	public PurchaseHistoryEntity(int purId,/* BuyerEntity buyerId,  int transactionId, ItemsEntity itemId,*/ int numberOfItems,
			String purchremarks) {
		super();
		this.purchaseId = purId;
		//this.buyerId = buyerId;
		
		//this.transactionId = transactionId;
		//this.itemId = itemId;
		this.numberOfItems = numberOfItems;
		this.purchremarks = purchremarks;
	}
	/*@Override
	public String toString() {
		return "PurchaseHistoryEntity [purId=" + purchaseId + ", buyerId=" + buyerId + ", transactionId=" + transactionId
				+ ", itemId=" + itemId + ", numberOfItems=" + numberOfItems + ", dateItme=" + dateItme
				+ ", purchremarks=" + purchremarks + "]";
	}*/
	@Override
	public String toString() {
		return "PurchaseHistoryEntity [purchaseId=" + purchaseId + ", numberOfItems=" + numberOfItems + ", dateItme="
				+ dateTime + ", purchremarks=" + purchremarks + "]";
	}
	
	
	
	


}
