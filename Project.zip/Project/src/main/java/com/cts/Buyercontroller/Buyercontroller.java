package com.cts.Buyercontroller;

//import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.Buyer.Buyer;
import com.cts.BuyerInterfaceservice.IBuyerService;


@RestController
public class Buyercontroller {

	@Autowired
	private IBuyerService service;
/*@RequestMapping("getAll")
	public List<Buyer> getAll(){
		
		return service.getAllPersons();
	}*/
	@RequestMapping(value = "/buyer", method = RequestMethod.POST, produces = "application/json")
	public Integer createOrUpdate (@RequestBody Buyer buyer) {
		
		return service.createOrUpdate(buyer);
	}
	@RequestMapping("getById/{buid}")
	public Buyer getBuyerById(@PathVariable("buid") Integer id)
	{
		return service.getBuyerById(id);
	}
	@RequestMapping("getByName/{buname}")
	public Buyer getBuyerByName(@PathVariable("buname") String name){
		
		return service.getBuyerByName(name);
	}
	
	@RequestMapping(value = "deleteById/{bid}", method = RequestMethod.DELETE)
	public void deleteById(@PathVariable("bid") Integer buyerId) {
		
		service.deleteById(buyerId);
	}
	@RequestMapping(value="/update", method = RequestMethod.PUT)
	public Buyer updatePerson(@RequestBody Buyer buyer) {
		
		return service.update(buyer);
	}
}
