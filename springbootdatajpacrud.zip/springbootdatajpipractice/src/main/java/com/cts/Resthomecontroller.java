package com.cts;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Resthomecontroller {
@Autowired
private Interfaceproductservice s;
@RequestMapping("getAllProducts")
public List<Product> getAllProducts() {
    return s.findAll();
}

@RequestMapping("/Products")
Product  createOrSaveProduct(@RequestBody Product newProduct) {
    return s.save(newProduct);
}

@RequestMapping("/products/{id}")
Product getProductById(@PathVariable int id) {
    return s.findById(id).get();
}

@RequestMapping("/products/{id}")
Product updateProduct(@RequestBody Product newProduct, @PathVariable int id) {

    return (s.findById(id)).List(product -> {
        product.setpname(newProduct.getpname());
        product.setprice(newProduct.getprice());
        product.setquantity(newProduct.getquantity());
        return s.save(product);
    }).orElseGet(() -> {
        newProduct.setId(id);
        return s.save(newProduct);
    });
}

@RequestMapping("/products/{id}")
void deleteProduct(@PathVariable int id) {
    s.deleteById(id);
}
}
