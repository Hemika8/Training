package com.cts;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class Productservice implements Interfaceproductservice{
@Autowired
private Interfaceproductdao dao;
@Override
public List<Product> findAll() {
	// TODO Auto-generated method stub
	return dao.findAll();
}

@Override
public Product save(Product newProduct) {
	// TODO Auto-generated method stub
	return dao.save(newProduct);
}

@Override
public Object findById(int id) {
	// TODO Auto-generated method stub
	return dao.findById(id);
}

@Override
public void deleteById(int id) {
	// TODO Auto-generated method stub
	
}


}
