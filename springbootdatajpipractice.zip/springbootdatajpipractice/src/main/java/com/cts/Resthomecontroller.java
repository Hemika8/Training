package com.cts;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Resthomecontroller {
@Autowired
private Interfaceproductservice s;
@RequestMapping("add")
public Product add()
{
	return s.addProduct();
}
@RequestMapping("update")
}
