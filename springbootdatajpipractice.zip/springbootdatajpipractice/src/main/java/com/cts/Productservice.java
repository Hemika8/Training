package com.cts;

import org.springframework.beans.factory.annotation.Autowired;

public class Productservice implements Interfaceproductservice{
@Autowired
private Interfaceproductdao dao;
public Product addProduct()
{
	return dao.save(Product);
}
}
