package com.cts;

import java.util.List;

public interface Interfaceproductservice {

			List<Product> findAll();

			Product save(Product newProduct);

			Object findById(int id);

			void deleteById(int id);

		
			

}
