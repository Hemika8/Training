package com.cts;

public interface Interfaceproductservice {

	Product addProduct();

}
