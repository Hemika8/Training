package com.cts;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Interfaceproductdao extends JpaRepository<Product, Integer > {

	

	

}
