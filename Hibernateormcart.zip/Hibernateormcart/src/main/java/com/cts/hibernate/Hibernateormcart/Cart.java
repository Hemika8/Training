package com.cts.hibernate.Hibernateormcart;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
@Entity
public class Cart {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
private int cart_id;
	@OneToMany(mappedBy="product")
	private int pid;
		List<Product> li=new ArrayList();
	public Cart() {
		// TODO Auto-generated constructor stub
	}
		public Cart(int cart_id) {
		super();
		this.cart_id = cart_id;
	}
	public int getCart_id() {
		return cart_id;
	}
public void setCart_id(int cart_id) {
	this.cart_id = cart_id;
}

}
